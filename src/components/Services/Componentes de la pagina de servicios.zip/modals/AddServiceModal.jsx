// src/components/Services/AddServiceModal.jsx
import { useState, useEffect } from "react";
import { createService } from "@/api/services";
import { getAllWorkers } from "@/api/worker";
import { getServiceTypes } from "@/api/serviceTypes";
import ManageServiceTypesModal from "./ManageServiceTypesModal";

export default function AddServiceModal({
  isOpen,
  onClose,
  lastMileage = 0,
  vehicleId,
  onSuccess,
}) {
  const [entryDate, setEntryDate] = useState(
    new Date().toISOString().slice(0, 16)
  );
  const [mileage, setMileage] = useState(lastMileage);
  const [serviceType, setServiceType] = useState("");
  const [description, setDescription] = useState("");
  const [mechanicNotes, setMechanicNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [workers, setWorkers] = useState([]);
  const [workerId, setWorkerId] = useState("");
  const [serviceTypes, setServiceTypes] = useState([]);
  const [manageOpen, setManageOpen] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await createService({
        vehicleId,
        entryDate: new Date(entryDate).toISOString(),
        mileage: parseInt(mileage),
        serviceType,
        description,
        mechanicNotes,
        workerId,
      });
      onSuccess?.();
      onClose();
    } catch (err) {
      console.error("Error al crear servicio:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setEntryDate(new Date().toISOString().slice(0, 16));
      setMileage(lastMileage);
      setServiceType("");
      setDescription("");
      setMechanicNotes("");
      setWorkerId("");
      getAllWorkers().then(setWorkers);
      getServiceTypes().then(setServiceTypes);
    }
  }, [isOpen, lastMileage]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[90] bg-black/40 backdrop-blur-sm flex justify-center  items-center p-4 pointer-events-none">
      <div className="bg-white rounded-2xl shadow-2xl ring-1 ring-black/5 max-h-[90vh] overflow-scroll max-w-lg w-full pointer-events-auto">
        {/* Header — solo X cierra */}
        <div className="px-6 py-4 border-b flex items-center justify-between">
          <h2 className="text-xl font-semibold">Registrar Nuevo Servicio</h2>
          <button
            onClick={onClose}
            className="text-2xl leading-none px-2 rounded hover:bg-gray-100"
            aria-label="Cerrar"
          >
            &times;
          </button>
        </div>

        {/* Body — estilo “Complete Service” */}
        <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4 text-sm">
          {/* Fecha */}
          <label className="block">
            <span className="text-xs font-medium text-gray-600">
              Fecha y Hora de Entrada
            </span>
            <input
              type="datetime-local"
              value={entryDate}
              onChange={(e) => setEntryDate(e.target.value)}
              className="mt-1 w-full rounded-xl border border-gray-300 bg-white px-3 py-2 shadow-sm focus:outline-none focus:ring-4 focus:ring-violet-200 focus:border-violet-400"
              required
            />
          </label>

          {/* Mecánico */}
          <label className="block">
            <span className="text-xs font-medium text-gray-600">
              Mecánico Responsable
            </span>
            <select
              value={workerId}
              onChange={(e) => setWorkerId(e.target.value)}
              className="mt-1 w-full rounded-xl border border-gray-300 bg-white px-3 py-2 shadow-sm focus:outline-none focus:ring-4 focus:ring-violet-200 focus:border-violet-400"
              required
            >
              <option value="">Selecciona un mecánico</option>
              {workers.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>
          </label>

          {/* Kilometraje */}
          <label className="block">
            <span className="text-xs font-medium text-gray-600">
              Kilometraje
            </span>
            <input
              type="number"
              value={mileage}
              onChange={(e) => setMileage(e.target.value)}
              min="0"
              className="mt-1 w-full rounded-xl border border-gray-300 bg-white px-3 py-2 shadow-sm focus:outline-none focus:ring-4 focus:ring-violet-200 focus:border-violet-400"
              required
            />
          </label>

          {/* Tipo de servicio + gestionar */}
          <div>
            <span className="text-xs font-medium text-gray-600">
              Tipo de servicio
            </span>
            <div className="mt-1 flex flex-wrap items-center gap-2">
              <select
                value={serviceType}
                onChange={(e) => setServiceType(e.target.value)}
                className="min-w-0 flex-1 max-w-full rounded-xl border border-gray-300 bg-white px-3 py-2 shadow-sm focus:outline-none focus:ring-4 focus:ring-violet-200 focus:border-violet-400"
                required
              >
                <option value="">Selecciona un tipo</option>
                {serviceTypes.map((t) => (
                  <option key={t.id} value={t.serviceTypeName}>
                    {t.serviceTypeName}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={() => setManageOpen(true)}
                className="shrink-0 whitespace-nowrap px-4 py-2 rounded-xl border border-gray-300 text-sm hover:bg-gray-50"
              >
                Gestionar
              </button>
            </div>
          </div>

          {/* Descripción */}
          <label className="block">
            <span className="text-xs font-medium text-gray-600">
              Descripción
            </span>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="mt-1 w-full rounded-xl border border-gray-300 bg-white p-3 shadow-sm focus:outline-none focus:ring-4 focus:ring-violet-200 focus:border-violet-400"
            />
          </label>

          {/* Notas del mecánico */}
          <label className="block">
            <span className="text-xs font-medium text-gray-600">
              Notas del mecánico
            </span>
            <textarea
              value={mechanicNotes}
              onChange={(e) => setMechanicNotes(e.target.value)}
              rows={3}
              className="mt-1 w-full rounded-xl border border-gray-300 bg-white p-3 shadow-sm focus:outline-none focus:ring-4 focus:ring-violet-200 focus:border-violet-400"
            />
          </label>
        </form>

        {/* Footer */}
        <div className="px-6 py-4 border-t bg-white/95 backdrop-blur flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            type="button"
            className="px-4 py-2 rounded-xl border border-gray-300 text-sm hover:bg-gray-50"
          >
            Cancelar
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="px-4 py-2 rounded-xl bg-gray-900 text-white text-sm hover:bg-black disabled:opacity-60"
          >
            {loading ? "Guardando..." : "Registrar Servicio"}
          </button>
        </div>

        {/* Modal para gestionar tipos */}
        {manageOpen && (
          <ManageServiceTypesModal
            isOpen={manageOpen}
            onClose={() => setManageOpen(false)}
            onChanged={() => getServiceTypes().then(setServiceTypes)}
          />
        )}
      </div>
    </div>
  );
}
