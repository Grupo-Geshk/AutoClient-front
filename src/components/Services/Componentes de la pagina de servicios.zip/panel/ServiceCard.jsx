import Badge from "../ui/Badge";
import InfoRow from "../ui/InfoRow";
import {
  MileageIcon, CalendarIcon, EntryDateIcon, PendingIcon, ViewIcon
} from "@/components/icons/ServicesIcons";
import { CompletedIcon } from "@/components/icons/StatsIcons";

const none = (v) => (v === null || v === undefined || v === "" ? "—" : v);
const fmt  = (n) => (n === null || n === undefined || n === "" ? "—" : Number(n).toLocaleString("es-PA"));

export default function ServiceCard({ service, onView, onMain }) {
  const pending = !service.exitDate;

  const formatDate = (ds) => {
    const date = new Date(ds);
    return new Intl.DateTimeFormat("es-PA", { day: "2-digit", month: "short", year: "numeric" })
      .format(date)
      .replace(".", "")
      .replace(/(\d{2}) (\w+) (\d{4})/, "$1 de $2 del $3");
  };

  return (
    <article className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm hover:bg-gray-50 transition-colors">
      {/* Top: identidad + estado + acciones */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm text-gray-500">Cliente:</span>
            <span className="font-semibold truncate max-w-[14rem]" title={none(service.clientName)}>
              {none(service.clientName)}
            </span>
            <Badge tone="slate">{none(service.plateNumber)}</Badge>
            {(service.brand || service.model || service.year) && (
              <Badge tone="violet">{`${none(service.brand)} ${none(service.model)} ${none(service.year)}`}</Badge>
            )}
          </div>

          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Badge tone={pending ? "yellow" : "green"}>
              <span className="mr-1 inline-block align-middle">
                {pending ? <PendingIcon /> : <CompletedIcon />}
              </span>
              {pending ? "Pendiente" : "Completado"}
            </Badge>

            <span className="text-sm text-gray-600">
              {pending ? "Iniciado Por" : "Completado Por"}{" "}
              <span className="font-medium">{none(service.workerName)}</span>
            </span>
          </div>
        </div>

        {/* Acciones */}
        <div className="flex items-center gap-2">
          <button
            onClick={onView}
            className="rounded-lg p-2 ring-1 ring-green-300 text-green-700"
            aria-label="Ver detalles"
            title="Ver detalles"
          >
            <ViewIcon />
          </button>
          <button
            onClick={onMain}
            className={`rounded-lg p-2 ring-1 ${pending ? "ring-yellow-300 text-yellow-700" : "ring-green-300 text-green-700"}`}
            aria-label={pending ? "Completar servicio" : "Editar notas"}
            title={pending ? "Completar servicio" : "Editar notas"}
          >
            {pending ? <PendingIcon /> : <CompletedIcon />}
          </button>
        </div>
      </div>

      {/* Datos */}
      <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 text-sm">
        <InfoRow icon={<MileageIcon />} label="Kilometraje" value={fmt(service.mileage)} />
        <InfoRow icon={<CalendarIcon />} label="Último" value={service.exitDate ? none(service.haceCuantosDias) : "—"} />
        <InfoRow icon={<CalendarIcon />} label="Fecha" value={service.exitDate ? formatDate(service.exitDate) : "—"} />
        <InfoRow label="Km esperado" value={fmt(service.nextServiceMileageTarget)} />
        <InfoRow icon={<EntryDateIcon />} label="Recibido el" value={formatDate(service.entryDate)} />
      </div>

      {/* Notas / Costo */}
      <div className="mt-3 divide-y divide-gray-100 rounded-lg border border-gray-100">
        {!service.exitDate && service.mechanicNotes && (
          <div className="p-3 text-sm text-gray-700">
            <span className="text-gray-500">Notas: </span>
            <span className="line-clamp-2" title={service.mechanicNotes}>{service.mechanicNotes}</span>
            <span className="text-gray-400"> {none(service.description)}</span>
          </div>
        )}

        {service.exitDate && (
          <div className="p-3 text-sm">
            <span className="text-gray-500">Costo: </span>
            <span className="font-semibold">{`$ ${fmt(service.cost)}`}</span>
          </div>
        )}
      </div>
    </article>
  );
}
